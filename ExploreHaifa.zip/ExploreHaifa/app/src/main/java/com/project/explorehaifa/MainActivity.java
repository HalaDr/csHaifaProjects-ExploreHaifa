package com.project.explorehaifa;

import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    TextView textView;
    RequestQueue queue;


    //String URL = "http://www.mocky.io/v2/597c41390f0000d002f4dbd1";
    String URL=  "https://data.gov.il/api/3/action/datastore_search?resource_id=29b0e043-706d-47d3-b1b4-b6d57c27c450&limit=5";
    @RequiresApi(api = Build.VERSION_CODES.N)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        textView = findViewById(R.id.text);
        queue = Volley.newRequestQueue(this);
        StringRequest request = new StringRequest(Request.Method.GET, URL, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                String response_json = response.toString();
                textView.setText(response_json);

                Toast.makeText(MainActivity.this,response.toString(),Toast.LENGTH_LONG).show();

                ArrayList<Synagogue> listSynagogues = new ArrayList<>();

                JSONObject root_obj=null;
                JSONArray records=null;
                JSONObject record=null;

                try {
                    root_obj = new JSONObject(response_json);
                    // textView.setText(root_obj.getString("success"));
                    records = root_obj.getJSONObject("result").getJSONArray("records");
                    String names="";
                    int length= records.length();
                    for(int i=0;i<length;i++)
                    {
                        record=records.getJSONObject(i);
                        names+=record.getString("שם")+"\n";
                        Synagogue synagogue = new Synagogue();
                        synagogue.setName(record.getString("שם"));
                        synagogue.setNeighbourhood(record.getString("שכונה"));
                        synagogue.setAddress(record.getString("כתובת"));
                        listSynagogues.add(synagogue);
                    }
                    textView.setText(names);

                } catch (JSONException e) {
                    Toast.makeText(MainActivity.this,e.getMessage(),Toast.LENGTH_LONG).show();

                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Log.d("error",error.toString());
            }
        });
        queue.add(request);
    }
}



